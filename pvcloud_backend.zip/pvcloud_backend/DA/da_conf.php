<?php
/**
 * Description of DAConf
 *
 * @author janunezc
 */
class DAConf {
    public static $databaseURL = "localhost";
    public static $databaseUName = "root";
    public static $databasePWord = "";
    public static $databaseName = "pvcloud";
}
